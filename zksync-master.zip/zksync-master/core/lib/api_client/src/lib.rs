#![allow(clippy::derive_partial_eq_without_eq)]
pub mod rest;
