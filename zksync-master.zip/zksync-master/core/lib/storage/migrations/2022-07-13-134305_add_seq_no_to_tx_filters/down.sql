ALTER TABLE tx_filters DROP COLUMN sequence_number;
ALTER TABLE tx_filters DROP COLUMN is_priority;
