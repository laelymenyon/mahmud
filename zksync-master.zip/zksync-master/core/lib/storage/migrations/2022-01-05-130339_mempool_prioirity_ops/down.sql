DROP TABLE IF EXISTS mempool_priority_operations;
