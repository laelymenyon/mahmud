ALTER TABLE account_tree_cache
    ALTER COLUMN tree_cache TYPE jsonb;
