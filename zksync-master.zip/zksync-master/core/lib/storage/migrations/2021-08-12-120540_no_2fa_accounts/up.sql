ALTER TYPE eth_account_type ADD VALUE 'No2FA';
