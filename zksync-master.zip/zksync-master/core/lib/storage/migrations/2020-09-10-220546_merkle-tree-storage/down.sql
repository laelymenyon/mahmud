DROP TABLE IF EXISTS account_tree_cache;
