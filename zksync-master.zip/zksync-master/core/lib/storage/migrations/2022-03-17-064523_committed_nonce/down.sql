DROP TABLE IF EXISTS committed_nonce;
