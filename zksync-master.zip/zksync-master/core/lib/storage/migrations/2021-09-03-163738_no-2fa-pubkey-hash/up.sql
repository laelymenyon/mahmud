CREATE TABLE no_2fa_pub_key_hash
(
    account_id BIGINT PRIMARY KEY,
    pub_key_hash TEXT NOT NULL
);
