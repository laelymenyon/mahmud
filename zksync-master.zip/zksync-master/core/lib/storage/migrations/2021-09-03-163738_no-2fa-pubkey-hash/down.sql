DROP TABLE IF EXISTS no_2fa_pub_key_hash;
