ALTER TABLE data_restore_rollup_ops DROP COLUMN timestamp BIGINT;
ALTER TABLE data_restore_rollup_ops DROP COLUMN previous_block_root_hash bytea;
