ALTER TABLE data_restore_rollup_ops ADD timestamp bigint;
ALTER TABLE data_restore_rollup_ops ADD previous_block_root_hash bytea;

