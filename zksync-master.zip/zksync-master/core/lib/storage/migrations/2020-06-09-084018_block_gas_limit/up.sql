
ALTER TABLE blocks ADD commit_gas_limit BIGINT NOT NULL;
ALTER TABLE blocks ADD verify_gas_limit BIGINT NOT NULL;
