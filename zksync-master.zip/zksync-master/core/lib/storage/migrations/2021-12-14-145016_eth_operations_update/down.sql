ALTER TABLE eth_operations DROP created_at;
