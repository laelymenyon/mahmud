ALTER TABLE eth_operations ADD created_at TIMESTAMP with time zone DEFAULT now();
