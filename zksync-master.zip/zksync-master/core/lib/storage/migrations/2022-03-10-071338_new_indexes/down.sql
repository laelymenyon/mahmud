DROP INDEX IF EXISTS executed_priority_operations_tx_hash_idx;
DROP INDEX IF EXISTS mint_nft_updates_account_id_block_number;
DROP INDEX IF EXISTS nft_creator_id_idx;
DROP INDEX IF EXISTS aggregate_operations_type_idx;
DROP INDEX IF EXISTS tokens_kind_idx;
DROP INDEX IF EXISTS tokens_symbol_idx;
