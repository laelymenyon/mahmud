DROP TABLE IF EXISTS tx_filters;
DROP INDEX IF EXISTS tx_filters_address_idx;
