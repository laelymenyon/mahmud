DROP TABLE ticker_market_volume;
