DROP TABLE account_tree_cache_new;
