DROP TABLE IF EXISTS data_restore_priority_op_data;
