DROP TABLE IF EXISTS ticker_price;
