ALTER TABLE eth_parameters DROP COLUMN average_gas_price BIGINT;
