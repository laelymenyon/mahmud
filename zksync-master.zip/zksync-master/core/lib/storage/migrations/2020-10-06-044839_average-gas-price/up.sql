ALTER TABLE eth_parameters ADD average_gas_price BIGINT;
