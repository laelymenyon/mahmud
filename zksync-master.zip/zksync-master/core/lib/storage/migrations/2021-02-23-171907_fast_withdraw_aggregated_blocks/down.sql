drop table block_metadata;
