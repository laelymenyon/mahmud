ALTER TABLE mint_nft_updates DROP COLUMN nonce;
