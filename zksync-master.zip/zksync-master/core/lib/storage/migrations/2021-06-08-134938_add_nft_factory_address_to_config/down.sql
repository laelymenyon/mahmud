ALTER TABLE server_config DROP COLUMN nft_factory_addr;
