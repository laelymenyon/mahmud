ALTER TABLE server_config ADD COLUMN nft_factory_addr TEXT;
