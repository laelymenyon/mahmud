CREATE INDEX account_pubkey_updates_account_idx ON  account_pubkey_updates (account_id);
CREATE INDEX account_balance_updates_account_id_idx ON  account_balance_updates (account_id);
