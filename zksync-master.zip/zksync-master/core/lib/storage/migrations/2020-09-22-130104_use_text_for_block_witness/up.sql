ALTER TABLE block_witness
    ALTER COLUMN witness TYPE TEXT;
