DROP PROCEDURE unique_users;
