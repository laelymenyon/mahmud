ALTER TABLE tokens 
	ADD UNIQUE  (symbol), ADD UNIQUE (address);
