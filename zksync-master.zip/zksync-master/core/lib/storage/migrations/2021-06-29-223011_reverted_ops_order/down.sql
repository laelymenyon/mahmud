ALTER TABLE mempool_txs DROP COLUMN next_priority_op_serial_id;
