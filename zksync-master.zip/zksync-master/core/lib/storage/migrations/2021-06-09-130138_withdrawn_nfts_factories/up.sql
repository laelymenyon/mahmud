CREATE TABLE withdrawn_nfts_factories
(
    token_id INT PRIMARY KEY,
    factory_address TEXT NOT NULL
);
