use zksync_basic_types::{AccountId, BlockNumber, H256};
use zksync_crypto::ff::Field;
use zksync_crypto::Fr;

use super::utils::*;
use crate::block::Block;

/// Checks that we cannot create a block with invalid block sizes provided.
#[test]
#[should_panic]
fn no_supported_block_size() {
    Block::new_from_available_block_sizes(
        BlockNumber(0),
        Default::default(),
        AccountId(0),
        vec![create_withdraw_tx()],
        (0, 0),
        &[0],
        1_000_000.into(),
        1_500_000.into(),
        H256::default(),
        0,
    );
}

/// Checks that the byte order is indeed big-endian.
#[test]
fn test_get_eth_encoded_root() {
    let block = Block::new(
        BlockNumber(0),
        Fr::one(),
        AccountId(0),
        vec![],
        (0, 0),
        1,
        1_000_000.into(),
        1_500_000.into(),
        H256::default(),
        0,
    );

    let mut bytes = [0u8; 32];
    let byte = bytes.last_mut().unwrap();
    *byte = 1;

    assert_eq!(block.get_eth_encoded_root(), H256::from(bytes));
}

#[test]
fn test_get_eth_public_data() {
    let mut block = Block::new(
        BlockNumber(0),
        Fr::one(),
        AccountId(0),
        vec![
            create_change_pubkey_tx(),
            create_full_exit_op(),
            create_withdraw_tx(),
        ],
        (0, 0),
        100,
        1_000_000.into(),
        1_500_000.into(),
        H256::default(),
        0,
    );

    let expected = {
        let mut data = vec![];
        for op in &block.block_transactions {
            data.extend(op.get_executed_op().unwrap().public_data());
        }
        data
    };

    let mut result = block.get_eth_public_data();
    // Skip the padding.
    result.truncate(expected.len());

    assert_eq!(result, expected);

    block.block_transactions = vec![];
    // Vec will be padded again.
    assert!(block.get_eth_public_data().iter().all(|&i| i == 0));
}

#[test]
fn test_get_eth_witness_data() {
    let operations = vec![
        create_change_pubkey_tx(),
        create_full_exit_op(),
        create_withdraw_tx(),
        create_change_pubkey_tx(),
    ];
    let change_pubkey_tx_1 = &operations[0];
    let change_pubkey_tx_2 = &operations[3];
    let mut block = Block::new(
        BlockNumber(0),
        Fr::one(),
        AccountId(0),
        operations.clone(),
        (0, 0),
        100,
        1_000_000.into(),
        1_500_000.into(),
        H256::default(),
        0,
    );

    let witness_1 = change_pubkey_tx_1
        .get_executed_op()
        .unwrap()
        .eth_witness()
        .unwrap();
    let witness_2 = change_pubkey_tx_2
        .get_executed_op()
        .unwrap()
        .eth_witness()
        .unwrap();
    let used_bytes_1 = witness_1.len() as u64;
    let used_bytes_2 = witness_2.len() as u64;

    let expected = (
        [&witness_1[..], &witness_2[..]].concat(),
        vec![used_bytes_1, used_bytes_2],
    );

    assert_eq!(block.get_eth_witness_data(), expected);

    block.block_transactions.pop();
    let expected = (witness_1, vec![used_bytes_1]);
    assert_eq!(block.get_eth_witness_data(), expected);

    // Remove the last operation which has witness data.
    block.block_transactions.remove(0);
    assert!(block.get_eth_witness_data().0.is_empty());
}

#[test]
fn test_get_withdrawals_data() {
    let operations = vec![
        create_change_pubkey_tx(),
        create_full_exit_op(),
        create_withdraw_tx(),
    ];
    let mut block = Block::new(
        BlockNumber(0),
        Fr::one(),
        AccountId(0),
        operations.clone(),
        (0, 0),
        100,
        1_000_000.into(),
        1_500_000.into(),
        H256::default(),
        0,
    );

    let expected = {
        let mut data = vec![];
        for op in &operations[1..] {
            data.extend(op.get_executed_op().unwrap().withdrawal_data().unwrap());
        }
        data
    };

    assert_eq!(block.get_withdrawals_data(), expected);

    block.block_transactions.pop();
    assert!(!block.get_withdrawals_data().is_empty());

    block.block_transactions.pop();
    // No more corresponding operations left.
    assert!(block.get_withdrawals_data().is_empty());
}
