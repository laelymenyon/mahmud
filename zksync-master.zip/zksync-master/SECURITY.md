# Security Policy / Bug Bounty Program

The description of the Security Policy and the Bug Bounty program can be read
[here](https://zksync.io/dev/bug-bounty.html)
