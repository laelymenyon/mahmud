module.exports = {
    ...require('../etc/prettier-config/ts.js')
};
