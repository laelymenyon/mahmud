module.exports = {
    ...require('../etc/lint-config/ts.js')
};
